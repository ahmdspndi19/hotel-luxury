<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class KeepAdminInPanel
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && $user->canany(['manage cities', 'manage countries', 'manage hotels', 'manage hotel bookings'])) {
            return redirect()->route('dashboard');
        }

        return $next($request);
    }
}
