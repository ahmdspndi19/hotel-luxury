<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Country extends Model
{
    use HasFactory, SoftDeletes;

    // Tambahkan 'slug' ke dalam array ini
    protected $fillable = ['name', 'slug'];

    public function hotels(){
        return $this->hasMany(Hotel::class);
    }
}
